module CabalMessage where

message = "This is Cabal-99999"
