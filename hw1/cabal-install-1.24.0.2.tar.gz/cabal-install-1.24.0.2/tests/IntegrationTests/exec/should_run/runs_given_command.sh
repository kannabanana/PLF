. ../common.sh
cabal configure > /dev/null
cabal exec echo this string
