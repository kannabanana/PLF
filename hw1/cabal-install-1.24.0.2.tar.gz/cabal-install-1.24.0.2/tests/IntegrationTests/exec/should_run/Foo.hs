module Foo where

foo :: String
foo = "foo"
