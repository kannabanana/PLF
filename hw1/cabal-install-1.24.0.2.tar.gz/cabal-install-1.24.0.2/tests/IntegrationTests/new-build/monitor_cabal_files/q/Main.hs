module Main where
import P
main :: IO ()
main = return ()
