. ../common.sh
cabal freeze
